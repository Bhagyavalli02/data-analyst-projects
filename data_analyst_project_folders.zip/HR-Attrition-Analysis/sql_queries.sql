
-- Attrition Rate
SELECT 
COUNT(CASE WHEN attrition='Yes' THEN 1 END) * 100.0 / COUNT(*) AS attrition_rate
FROM employees;

-- Average Salary by Department
SELECT department, AVG(salary) AS avg_salary
FROM employees
GROUP BY department;

-- Employees with more than 5 years experience
SELECT employee_id, years_at_company
FROM employees
WHERE years_at_company > 5;
