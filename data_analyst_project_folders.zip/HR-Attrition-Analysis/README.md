
# HR Analytics & Employee Attrition Analysis

## Tools
SQL, Excel, Power BI / Tableau

## Description
This project analyzes employee attrition patterns and workforce distribution to identify high‑risk employee groups.

## Key Analysis
- Attrition rate calculation
- Department-wise turnover
- Salary distribution
- Average tenure analysis

## Files
- dataset.csv – sample employee dataset
- sql_queries.sql – SQL queries used for analysis
- dashboard_notes.txt – explanation of HR metrics
