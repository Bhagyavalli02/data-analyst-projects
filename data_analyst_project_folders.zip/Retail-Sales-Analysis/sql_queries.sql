
-- Total Revenue
SELECT SUM(sales) AS total_revenue
FROM retail_sales;

-- Top 5 Products
SELECT product_name, SUM(sales) AS revenue
FROM retail_sales
GROUP BY product_name
ORDER BY revenue DESC
LIMIT 5;

-- Monthly Revenue
SELECT month, SUM(sales) AS monthly_revenue
FROM retail_sales
GROUP BY month
ORDER BY month;
