
# Retail Sales Performance & Customer Insights Dashboard

## Tools
SQL, Excel, Power BI / Tableau

## Description
This project analyzes retail sales data to identify top-performing products, revenue trends, and customer retention patterns.

## Key Analysis
- Top selling products
- Monthly revenue trends
- Customer retention analysis
- Profit by product category

## Files
- dataset.csv – sample sales dataset
- sql_queries.sql – SQL queries used for analysis
- dashboard_notes.txt – explanation of dashboard metrics
